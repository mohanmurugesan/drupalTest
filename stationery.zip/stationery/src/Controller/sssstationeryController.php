<?php
namespace Drupal\stationery\Controller;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use Drupal\Core\StringTranslation\TranslationInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Class stationeryController.
 *
 * @package Drupal\stationery\Controller
 */
class stationeryController extends ControllerBase {
	
	
  public function content() {
	  $siteUrl = 'https://www.thegazette.co.uk/all-notices/notice/data.json';
	  
	  $response = \Drupal::httpClient()->request('GET', $siteUrl);
	  $data = $response->getBody()->getContents();
	  $decoded = json_decode($data);
	  if (!$decoded) {
		throw new \Exception('Invalid data returned from API');
	  }
	  
	  $records = array();
	  $i  = 1;
	  foreach($decoded->entry as $key => $data){
		  
		  
	  }
	  echo "<pre>";print_r($decoded->entry);exit;
	  
	   $client = new \GuzzleHttp\Client();
    try {
      $res = $client->get($siteUrl, ['http_errors' => false]);
	  echo "<pre>";print_r($res->getBody());exit;
      return($res->getBody());
    } catch (RequestException $e) {
      return($this->t('Error'));
    }
	  
	//create table header
      /*   $header = array(
         'collection'=> t('SrNo'),
         'name' => t('Candidate Name'),
         'value' => t('Mobile Number'),
         );
*/
    //select records from table
   /* $query = \Drupal::database()->select('key_value', 'm');
    $query->fields('m', ['collection','name','value']);
    $pager = $query->extend('Drupal\Core\Database\Query\PagerSelectExtender')->limit(1);
      // The actual action of sorting the rows is here.
    $table_sort = $query->extend('Drupal\Core\Database\Query\TableSortExtender')
            ->orderByHeader($header);
    $result = $pager->execute();*/
	/*$sql   = 'SELECT collection, name, value FROM {key_value}';
	$count =  5;
	$query = pager_query($sql, $count);
	echo "<pre>";print_r($query);exit;
	*/
	
	
	
	/*
	
    $rows=array();
	$rows[] = array(
             'collection' =>1,
             'name' => 1,
             'value' => 1,
          
         );
		 $rows[] = array(
             'collection' =>1,
             'name' => 1,
             'value' => 1,
          
         );
		 $rows[] = array(
             'collection' =>1,
             'name' => 1,
             'value' => 1,
          
         );
		 $rows[] = array(
             'collection' =>1,
             'name' => 1,
             'value' => 1,
          
         );
		$per_page  = 2; 
		 $current_page = pager_default_initialize(count($rows), $per_page);
// Split your list into page sized chunks
$chunks = array_chunk($rows, $per_page, TRUE);
// Show the appropriate items from the list
$output = theme('table', array('header' => $header, 'rows' => $chunks[$current_page]));
// Show the pager
$output .= theme('pager', array('quantity',count($rows)));
*/	
  
}

}

