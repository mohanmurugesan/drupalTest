<?php
namespace Drupal\stationery\Controller;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;

/**
 * Class stationeryController.
 *
 * @package Drupal\stationery\Controller
 */
class stationeryController extends ControllerBase {
	
	
  public function content() {
	  
	//create table header
         $header = array(
         'collection'=> t('SrNo'),
         'name' => t('Candidate Name'),
         'value' => t('Mobile Number'),
         );

    //select records from table
    $query = \Drupal::database()->select('key_value', 'm');
    $query->fields('m', ['collection','name','value']);
    $pager = $query->extend('Drupal\Core\Database\Query\PagerSelectExtender')->limit(1);
      // The actual action of sorting the rows is here.
    $table_sort = $query->extend('Drupal\Core\Database\Query\TableSortExtender')
            ->orderByHeader($header);
    $result = $pager->execute();
	
    $rows=array();
	$rows[] = array(
             'collection' =>1,
             'name' => 1,
             'value' => 1,
          
         );
		 $rows[] = array(
             'collection' =>1,
             'name' => 1,
             'value' => 1,
          
         );
		 $rows[] = array(
             'collection' =>1,
             'name' => 1,
             'value' => 1,
          
         );
		 $rows[] = array(
             'collection' =>1,
             'name' => 1,
             'value' => 1,
          
         );
	
   /* foreach($result as $data){
		
        //print the data from table
         $rows[] = array(
             'collection' =>$data->collection,
             'name' => $data->name,
             'value' => $data->value,
          
         );
        
    } */
        //display data in site
         $form['table'] = [
         '#type' => 'table',
         '#header' => $header,
     '#rows' => $rows,
     '#empty' => t('No users found'),
     ];
	 
	 
      // Finally add the pager.
        $form['pager'] = array(
          '#type' => 'pager'
      );
     return $form;
}

}

