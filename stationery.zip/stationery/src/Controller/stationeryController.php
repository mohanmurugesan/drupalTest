<?php
namespace Drupal\stationery\Controller;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Component\Render\FormattableMarkup;
use Drupal\Core\Datetime\DrupalDateTime;

/**
 * Class stationeryController.
 *
 * @package Drupal\stationery\Controller
 */
class stationeryController extends ControllerBase {
	
	
  public function content() {
	  
	$pageVal = \Drupal::request()->query->get('page');
	if(empty($pageVal) || $pageVal == 0)
		  $pageVal = 1;
	
	 $header = array( array('data' => t('Title'), 'field' => 'title'),
					  array( 'data' => 'Publish'),array( 'data' => 'Content')	 );
     
	 $siteUrl = 'https://www.thegazette.co.uk/all-notices/notice/data.json?results-page='.$pageVal;
	
	  $response = \Drupal::httpClient()->request('GET', $siteUrl);
	  $data 	= $response->getBody()->getContents();
	  
	  $decoded 	= json_decode($data);
	
	  if (!$decoded) {
		throw new \Exception('Invalid data returned from API');
	  }
	  
	 $pager_manager = \Drupal::service('pager.manager');
	 $pager 		= $pager_manager->createPager(100, 10, 0);
	  
	  $records 		= array();
	  $i  = 1;
	  foreach($decoded->entry as $key => $data){
		  
		  $titleSource   = array('data' => new FormattableMarkup('<a href=":link">@name</a>', 
								[':link' => $data->id, 
								'@name' => $data->title])
							  );
							  
		  $date = new DrupalDateTime($data->published, 'UTC');
		  $formatted_date = \Drupal::service('date.formatter')->format($date->getTimestamp(), 'custom', 'd F Y');
		 
		  $rows[$key] = array('title' => $titleSource,'publish' => $formatted_date,'content' => htmlspecialchars_decode(htmlspecialchars($data->content)));
		  
	  }

  // Create table and pager
  $element['table'] = array(
    '#theme' => 'table',
    '#header' => $header,
    '#rows' => $rows,
    '#empty' => t('There is no data available.'),
  );

  $element['pager'] = array(
    '#type' => 'pager',
  );
  
  return $element;

}

public function _return_pager_for_array($items, $num_page) {
  // Get total items count
  $total = count($items);
  // Get the number of the current page
  $current_page = $this->pager_default_initialize($total, $num_page);
  // Split an array into chunks
  $chunks = array_chunk($items, $num_page);
  // Return current group item
  $current_page_items = $chunks[$current_page];

  return $current_page_items;
}


public function pager_default_initialize($total, $limit, $element = 0) {
  @trigger_error(__FUNCTION__ . ' is deprecated in drupal:8.8.0 and is removed from drupal:9.0.0. Use \Drupal\Core\Pager\PagerManagerInterface->createPager() instead. See https://www.drupal.org/node/2779457', E_USER_DEPRECATED);
  /* @var $pager_manager \Drupal\Core\Pager\PagerManagerInterface */
  $pager_manager = \Drupal::service('pager.manager');
  $pager = $pager_manager->createPager($total, $limit, $element);
  return $pager->getCurrentPage();
}


/**
 * Custom table sort
 *
 * @param array $rows
 *   Table rows which need sortable
 *
 * @param array $header
 *   Table header
 *
 * @param $flag
 *
 * @return array
 *
 * @see http://php.net/manual/ru/function.sort.php
 */
public function _records_nonsql_sort($rows, $header, $flag = SORT_STRING|SORT_FLAG_CASE) {
  $order = tablesort_get_order($header);
  $sort = tablesort_get_sort($header);
  $column = $order['sql'];
  foreach ($rows as $row) {
    $temp_array[] = $row[$column];
  }
  if ($sort == 'asc') {
    asort($temp_array, $flag);
  }
  else {
    arsort($temp_array, $flag);
  }

  foreach ($temp_array as $index => $data) {
    $new_rows[] = $rows[$index];
  }

  return $new_rows;
}

}

