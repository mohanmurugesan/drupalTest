<?php
namespace Drupal\stationery\Controller;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
use Drupal\Component\Render\FormattableMarkup;
use Drupal\Core\Datetime\DrupalDateTime;
use GuzzleHttp\Client;
use Drupal\Component\Utility;

/**
 @Author Mohan M
 * Class stationeryController.
 *
 * @package Drupal\stationery\Controller
 */
class stationeryController extends ControllerBase {
	
  /**
	Call the third party service and display the data.
	$apiUrl   = "https://www.thegazette.co.uk/all-notices/notice/data.json
  **/ 

  
  public function content() {
	
	// Get the pagination page 
	$pageVal = \Drupal::request()->query->get('page');
	
	if(empty($pageVal) || $pageVal == 0)
		$pageVal = 1;
	
	// Declare the header table content  
	$header	 =	array( array('data' => 'Title'),array( 'data' => 'Publish On'),array( 'data' => 'Content'));
   
	$siteUrl = 'https://www.thegazette.co.uk/all-notices/notice/data.json?results-page='.$pageVal;
	
	try {
		$response 	= \Drupal::httpClient()->request('GET', $siteUrl);
		
		if ($response->getStatusCode() != 200) {
		 \Drupal::logger('stationery')->error($response->getStatusCode());
		}
		
		$data 		= $response->getBody()->getContents();
	 }
	 catch (RequestException $e) {
		 \Drupal::logger('stationery')->error($message);
		
	 }

	  $decoded 	= json_decode($data);
	  $totalRecords  = $decoded->{'f:total'};
	 
	  if (!$decoded) {
		throw new \Exception('Invalid data returned from API');
	  }
	  
	 // Initiate the pagination 
	 $pager_manager = \Drupal::service('pager.manager');
	 $pager 		= $pager_manager->createPager($totalRecords, 10, 0);
	  
	  $records 		= array();
	 
	 //Arrage the received data
	foreach($decoded->entry as $key => $data){
	  
	  $titleSource   = array('data' => new FormattableMarkup('<a target="_blank" href=":link">@name</a>', 
							[':link' => $data->id, 
							'@name' => $data->title])
						  );
		
	  //Change the date format
	  $date 		  =  new DrupalDateTime($data->published, 'UTC');
	
	  $formatted_date =  \Drupal::service('date.formatter')->format($date->getTimestamp(), 'custom', 'd F Y');
	 //echo $data->content;exit;
	  $rows[$key] = array('title' => $titleSource,'publish' => $formatted_date,'content' => strip_tags($data->content));
		  
	  }

  // Create table and pager
  $element['table'] = array(
    '#theme' => 'table',
    '#header' => $header,
    '#rows' => $rows,
    '#empty' => t('There is no data available.'),
  );

  $element['pager'] = array(
    '#type' => 'pager',
  );
  
  return $element;

}

}
?>
